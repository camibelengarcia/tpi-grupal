history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/hostname
vim /etc/hostname
shutdown -r now
hostname
ls /root
cat /etc/debian_version
apt update
apt-get update
clear
apt update
ip a
cat /etc/resolv.conf
ping 8.8.8.8
apt update
ip route
ping google.com
apt update
cat /etc/sources.list
cat /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
apt upgrade
apt update
apt upgrade
apt-get upgrade
vim /etc/apt/sources.list
apt update
apt upgrade
cat /etc/debian_version
apt autoremove
shutdown -r now
cat /etc/debian_version
poweroff
ls
exit
ls
exit
exit
exit
apt update
cat /etc/sources.list
cat /etc/apt/sources.list
vim /etc/apt/sources.list
clear
apt update
vim /etc/apt/sources.list
apt update
vim /etc/apt/sources.list
apt update
apt upgrade
apt full-upgrade
apt update
apt autoremove
clear
apt install openshh-server
cat /etc/shh
apt install openssh-server
ssh
which ssh
systemctl status ssh
ls /root
clear
ls /root
ls -a /root
whatis hostname
man hostname
clear
ls /root
man tar
ls /root
man tar.gz
man gz
whatis tar
texinfo tar
info tar
man tar
grep gz man tar
man tar
clear
ls /root
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls /root
ls -l /root
cd Material_Adicional_TPVMCA
ls
ls -l
ls -al /root
ls /root/.ssh
cd ..
pwd
ls
ls -al /root/.ssh
ls -la /root
ls -la /root/.ssh
ls /root
ls /root/Material_Adicional_TPVMCA
ls /root/Material_Adicional_TPVMCA/clave_publica.pub > /root/.ssh/authorized_keys
ls -la /root/.ssh
chmod /root/.ssh/authorized_keys 700
chmod 700 /root/.ssh/authorized_keys
ls -la /root/.ssh
vim /etc/ssh/sshd_config
ip a
systemctl restart ssh
systemctl status ssh
ip a
clear
ip a
vim /etc/ssh/sshd_config
clear
systemctl restart ssh
vim /etc/ssh/sshd_config
clear
ls -la /root/.ssh
cat /root/.ssh/authorized_keys
grep -i "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
cat /root/.ssh/authorized_keys
cat /root/Material_Adicional_TPVMCA/clave_publica.pub > /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
clear
apt-cache search apache
apt search apache
apt search apache
apt search apache | tail
apt show apache
whatis apache
apt search apache2
apt show apache2
apt install apache2
apt show apache2
systemctl status apache2
apt install libapache2-mod-php
systemctl libapache2-mod-php
php -v
man php
clear
php -v
ls
ls -l
cat /var/www/html
cd /var/www/html
ls
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
ls
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls
rm index.html
ls
ls -la
apt show mariadb
apt search mariadb
apt search mariadb | less
clear
cd ..
cd ..
cd ..
pwd
cd /root
pwd
apt install mariadb-server
systemctl status mariadb-server
whatis mariadb
man mariadb
clear
cat /root/Material_Adicional_TPVMCA/db.sql
whereis apache
whereis php
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb -e "SHOW DATABASES;"
mariadb -e "SELECT * FROM ingenieria.alumnos;"
cat /root/Material_Adicional_TPVMCA/db.sql
shutdown -h now
lsblk
fdisk /dev/sdc
df -h
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
lsblk
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cat /etc/fstab
vim /etc/fstab
df -h
reboot
df -h
ls
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
ld /www_dir
ls /www_dir
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls /www_dir
lsblk
df -h
ls /www_dir
cat /etc/apache2
cd /etc/apache2
ls
whereis 000-default.conf
egrep 000-default.conf /etc/apache2
find 000-default.conf
find / -name 000-default.conf
find / -name hostname
whatis hostname
find / -name 000-default.conf
cd /etc/apache2/sites-available
ls
ls -l
cat 000-default.cong
cat 000-default.conf
vim /etc/apache2/sites-available/000-default.conf
cat 000-default.con
vim /etc/apache2/sites-enabled/000-default.conf
cat 000-default.conf
clear
cd /etc/apache2
ls
ip a
ls -l
vim /etc/apache2/apache2.conf
systemctl restart apache2
cd /root
systemctl restart apache2
reboot
systemctl status apache2
ls -l /www_dir
ls -la /www_dir
cat /www_dir/index.php
ip a
ls /var
ls /var/log
ls /var/log/apache2
ls /var/log/apache2/error.log
cat /var/log/apache2/error.log
whatis MySQLi
man MySQLi
man mysqli
apt search mysqli
apt search php mysql
apt search php mysql | head 
apt search php mysql
apt search php mysql | less
apt search php-mysql
apt install php-mysql
reboot
cd /opt
ls
ls /proc
cat /proc/partitions > /opt/particion
ls
ls -l
cat particion
vim /etc/network/interfaces
ping 8.8.8.8
reboot
ls
exit
cat /etc/hostname
cat /etc/debian_version
cat /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
apt upgrade
systemctl status ssh
cat /etc/ssh/sshd_config
cat /etc/ssh/sshd_config | less
cat /root/.ssh/authorized_keys
systemctl status apache2
systemctl status mariadb
cat /etc/network/interfaces
ip a
ping 8.8.8.8
lsblk
df -h
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
grep Directory /etc/apache2/apache2.conf
cat /opt/particion
reboot
ls /opt
ls /opt/scripts
cat backup_full.sh
cat /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log
man cron
clear
man cron
man crontab
vim /etc/crontab
cat /etc/crontab
reboot
